import qualified APL.Parser_Tests
import Test.Tasty (defaultMain)

main :: IO ()
main = defaultMain APL.Parser_Tests.tests
